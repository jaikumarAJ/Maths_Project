# SimpleLinearRegressionClassifier
This is a project that uses the Example in scikit-learn for a simple linear Regression classifier.
The book shows the codes in python but I have managed to translate it into java.
The Url for the book is https://github.com/PlamenStilyianov/Python3/blob/master/Mastering-Machine-Learning-scikit-learn/Mastering%20Machine%20Learning%20with%20scikit-learn.pdf

