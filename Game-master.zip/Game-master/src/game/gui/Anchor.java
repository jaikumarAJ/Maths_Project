package game.gui;

public enum Anchor 
{
    TOP,
    BOTTOM,
    LEFT,
    RIGHT
}
