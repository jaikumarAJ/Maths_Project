# mathequationparser
Math equation parser using shunting yard algorithm in Java



##Examples

Please enter a calculation:
nine over eight plus four times two divide-by three
Result: 3.79

Please enter a calculation:
one plus two
Result: 3

Please enter a calculation: 
one plus two times three 
Result: 7

Please enter a calculation:
nine minus three times seven
Result: -12

Please enter a calculation:
four minus eight plus six times nine
Result: 50

Please enter a calculation:
seven over nine plus one
Result: 1.78
