package com.pablosoftware.consolecalculator.app;

public class WrongFormatException extends Exception {

	
	private static final long serialVersionUID = 1L;

}
